import JSZip from 'jszip';
import { promises as fs } from 'fs';
import { join } from 'path';

const zip = new JSZip();

async function addFilesToZip(dir, parentFolder = zip) {
  const entries = await fs.readdir(dir, { withFileTypes: true });

  for (const entry of entries) {
    const path = join(dir, entry.name);

    // Skip node_modules, dist, and hidden files/folders
    if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name.startsWith('.')) {
      continue;
    }

    if (entry.isDirectory()) {
      await addFilesToZip(path, parentFolder.folder(entry.name));
    } else {
      const content = await fs.readFile(path);
      parentFolder.file(entry.name, content);
    }
  }
}

try {
  await addFilesToZip('.');
  const content = await zip.generateAsync({ type: 'nodebuffer' });
  await fs.writeFile('text-to-speech-project.zip', content);
  console.log('ZIP file created successfully: text-to-speech-project.zip');
} catch (error) {
  console.error('Error creating ZIP file:', error);
}